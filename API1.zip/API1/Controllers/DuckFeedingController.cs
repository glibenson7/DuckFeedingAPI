﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;

using API.Models;

namespace API.Controllers
{
    public class DuckFeedingController : ApiController
    {
        [HttpGet]
        [Route("api/duckFeedings")]
        public HttpResponseMessage GetDuckFeedings()
        {
            List<DuckFeeding> duckFeedings = new List<DuckFeeding>();

            duckFeedings.Add(new DuckFeeding(1, "Date & Time 1", "1", "1", 5, "1", 3, "0"));
            duckFeedings.Add(new DuckFeeding(2, "Date & Time 2", "2", "2", 3, "1", 2, "1"));
            duckFeedings.Add(new DuckFeeding(3, "Date & Time 3", "3", "3", 4, "3", 1, "2"));

            return Request.CreateResponse(HttpStatusCode.OK, duckFeedings);
        }

        /*
                [Route("duckFeedings")]
                public string Get()
                {
                    return "[ { 'id': 1, 'name': 'HR' }, { 'id': 4, 'name': 'IT' } ]"; // JsonConvert.SerializeObject(department);
                }
        */

        [HttpGet]
        [Route("api/duckFeeding/{id}")]
        public HttpResponseMessage GetDuckFeeding(int id)
        {
            DuckFeeding duckFeeding = new DuckFeeding();
            return Request.CreateResponse(HttpStatusCode.OK, duckFeeding);
        }

        // Duck Feeding / Create
        [HttpPost]
        [Route("api/duckFeeding/add")]
        public HttpResponseMessage Create()
        {
            return Request.CreateResponse(HttpStatusCode.OK, "DuckFeeding 1 was added");
        }

        // GET: User/Update/5
        [HttpPut]
        [Route("api/duckFeeding/update")]
        public HttpResponseMessage Update()
        {
            return Request.CreateResponse(HttpStatusCode.OK, "DuckFeeding 1 was updated");
        }

        // GET: User/Delete/5
        [HttpDelete]
        [Route("api/duckFeeding/delete")]
        public HttpResponseMessage Delete()
        {
            return Request.CreateResponse(HttpStatusCode.OK, "DuckFeeding 1 was deleted");
        }
    }
}
