﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;

using API.Models;

namespace API1.Controllers
{
    public class UserController : ApiController
    {
        [HttpGet]
        [Route("api/users")]
        public HttpResponseMessage GetUsers()
        {
            List<User> users = new List<User>();

            users.Add(new User(1, "UI1", "FN1", "LN1", "Email1", "Password1"));
            users.Add(new User(2, "UI2", "FN2", "LN2", "Email2", "Password2"));
            users.Add(new User(3, "UI3", "FN3", "LN3", "Email3", "Password3"));

            return Request.CreateResponse(HttpStatusCode.OK, users);
        }

        /*
                [Route("duckFeedings")]
                public string Get()
                {
                    return "[ { 'id': 1, 'name': 'HR' }, { 'id': 4, 'name': 'IT' } ]"; // JsonConvert.SerializeObject(department);
                }
        */

        [HttpGet]
        [Route("api/user/{id}")]
        public HttpResponseMessage GetUser(string userid)
        {
            User user = new User();
            return Request.CreateResponse(HttpStatusCode.OK, user);
        }

        // User / Create
        [HttpPost]
        [Route("api/user/add")]
        public HttpResponseMessage Create()
        {
            return Request.CreateResponse(HttpStatusCode.OK, "User 1 was added");
        }

        /*
        // GET: User/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: User/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: User/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: User/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        */
    }
}
