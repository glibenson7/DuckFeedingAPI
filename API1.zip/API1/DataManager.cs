﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API1
{
    public class DataManager
    {
    }

    // Server=localhost\SQLEXPRESS;Database=master;Trusted_Connection=True;

}