﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;

using API.Models;
using API.DataManagers;

namespace API.Controllers
{
    public class DuckFeedingController : ApiController
    {
        DuckFeeding_DataManager dataManager = new DuckFeeding_DataManager(); 

        [HttpGet]
        [Route("api/duckFeedingList")]
        public HttpResponseMessage GetDuckFeedingList()
        {            
            return Request.CreateResponse(HttpStatusCode.OK,
                dataManager.GetDuckFeedingList());
        }

        //[HttpGet]
        //[Route("api/duckFeeding/{id}")]  
        //public HttpResponseMessage GetDuckFeeding()
        //{
        //    DuckFeeding duckFeeding = new DuckFeeding();
        //    return Request.CreateResponse(HttpStatusCode.OK, duckFeeding);
        //}

        // Duck Feeding / Create
        [HttpPost]
        [Route("api/duckFeeding/add")]
        public HttpResponseMessage Create()
        {
            DuckFeeding df = new DuckFeeding();
           
            df.DateAndTime = "2021-08-08 08:30 am";
            df.DuckCount = 8;
            df.DuckFeedingId = 8;
            df.FoodDescId = 8;
            df.FoodKindId = 8;
            df.FoodQuantity = 8.8F;
            df.LocationId = 8;
            df.RepetitionDateRangeId = 8;
            df.Userid = "sam.smith";

            return Request.CreateResponse(HttpStatusCode.OK, dataManager.AddDuckFeeding(df));
        }

        // GET: User/Update/5
        [HttpPut]
        [Route("api/duckFeeding/update")]
        public HttpResponseMessage Update(DuckFeeding duckFeeding)
        {
            return Request.CreateResponse(HttpStatusCode.OK, "DuckFeeding " + duckFeeding.DuckFeedingId.ToString() + " was updated");
        }

        // GET: User/Delete/5
        [HttpDelete]
        [Route("api/duckFeeding/delete")]
        public HttpResponseMessage Delete(int duckFeedingId)
        {
            return Request.CreateResponse(HttpStatusCode.OK, "DuckFeeding " + duckFeedingId.ToString() + " was deleted");
        }
    }
}
