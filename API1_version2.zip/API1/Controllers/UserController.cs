﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;

using API.Models;
using API.DataManagers;

namespace API1.Controllers
{
    public class UserController : ApiController
    {
        User_DataManager dataManager = new User_DataManager();

        [HttpGet]
        [Route("api/users")]
        public HttpResponseMessage GetUsers()
        {
            return Request.CreateResponse(HttpStatusCode.OK, dataManager.GetUserList());
        }

        //[HttpGet]
        //[Route("api/user/{id}")]
        //public HttpResponseMessage GetUser(string userid)
        //{
        //    return Request.CreateResponse(HttpStatusCode.OK, dataManager.GetUser());
        //}

        // User / Create
        [HttpPost]
        [Route("api/user/add")]
        public HttpResponseMessage Create()
        {
            return Request.CreateResponse(HttpStatusCode.OK, dataManager.AddUser(new API.Models.User()));
        }

        /*
        // GET: User/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: User/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: User/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: User/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        */
    }
    }
