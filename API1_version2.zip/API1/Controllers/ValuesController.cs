﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using API.Models;

namespace API.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public HttpResponseMessage Get()
        {
            var retVal = new { key1 = "value1", key2 = "value2" };
            return Request.CreateResponse(HttpStatusCode.OK, retVal);
        }

        /*
               // GET api/values

               [Route("api/apirepo/total")]
               [HttpPost]
               public string GetTotal(string userid, CompanyData companyData)
               {
                   return "{ 'total': 3 }";
               }
       */

        //// GET api/total
        //[Route("api/total")]
        //public string Get()
        //{
        //    return "total-value";
        //}

        // POST api/values
        [Route("api/amount")]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [Route("api/quote")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
