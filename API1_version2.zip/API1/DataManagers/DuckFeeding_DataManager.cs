﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

using API.Models;
using API.DataManagers;

namespace API.DataManagers
{
    public class DuckFeeding_DataManager
    {
        string connectionString = 
            @"Server=localhost\SQLEXPRESS;Database=DuckFeedingDb;persist security info=True;Integrated Security=SSPI;";

        string queryString;
        SqlConnection connection;
        SqlCommand command;
        DataTable tbl;
        DataSet dataSet;
        SqlDataReader reader;
        DuckFeeding duckFeeding;

        public List<DuckFeeding> GetDuckFeedingList()
        {
            List<DuckFeeding> duckFeedingList = new List<DuckFeeding>();

            try
            {
                connection = new SqlConnection(connectionString);
                dataSet = new DataSet();
                tbl = new DataTable();

                queryString =
                    "SELECT DuckFeedingId, DateTime, FoodDescId, LocationId, " +
                           "DuckCount, FoodKindId, FoodQuantity, RepetitionDateRangeId " +
                    "FROM DuckFeedings "; 

                connection.Open();
                command = new SqlCommand(queryString, connection);

                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    duckFeedingList.Add(SetDuckFeedingFromDb(reader));
                }
            }
            catch (Exception exc)
            {
            }
            
            return duckFeedingList;
        }

        public DuckFeeding GetDuckFeeding()
        {
            duckFeeding = new DuckFeeding();

            try
            {
                connection = new SqlConnection(connectionString);
                dataSet = new DataSet();
                tbl = new DataTable();

                queryString =
                    "SELECT DuckFeedingId, DateTime, FoodDescId, LocationId,  " +
                           "DuckCount, FoodKindId, FoodQuantity, RepetitionDateRangeId," +
                           "Userid " +
                    "FROM DuckFeedings " +
                    "WHERE DuckFeedingId = 1;";

                connection.Open();
                command = new SqlCommand(queryString, connection);

                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    duckFeeding = SetDuckFeedingFromDb(reader);
                }
            }
            catch (Exception exc)
            {
            }

            return duckFeeding;
        }

        protected DuckFeeding SetDuckFeedingFromDb(SqlDataReader reader)
        {
            DuckFeeding duckFeeding = new DuckFeeding();

            try
            {
                duckFeeding.DuckFeedingId = reader.GetInt32(0);
                duckFeeding.DateAndTime = reader.GetString(1);
                duckFeeding.FoodDescId = reader.GetInt32(2);
                duckFeeding.LocationId = reader.GetInt32(3);
                duckFeeding.DuckCount = reader.GetInt32(4);
                duckFeeding.FoodKindId = reader.GetInt32(5);
                duckFeeding.FoodQuantity = (float)reader.GetDouble(6);
                duckFeeding.RepetitionDateRangeId = reader.GetInt32(7);
                duckFeeding.Userid = reader.GetString(8);
            }
            catch (Exception exc)
            {
            }

            return duckFeeding;
        }
        public int AddDuckFeeding(DuckFeeding duckFeeding)
        {
            int response = 0;

            try
            {
                connection = new SqlConnection(connectionString);
                command = new SqlCommand();
                command.CommandType = CommandType.Text;
                command.CommandText =
                    "INSERT INTO DuckFeedings " +
                    "(DuckFeedingId, DateTime, FoodDescId, LocationId, " +
                    " DuckCount, FoodKindId, FoodQuantity, RepetitionDateRangeId) " +

                    "VALUES (" + duckFeeding.DuckFeedingId + ", '" + duckFeeding.DateAndTime + "', " +
                    duckFeeding.FoodDescId + ", " + duckFeeding.LocationId + ", " +
                    duckFeeding.DuckCount + ", " + duckFeeding.FoodKindId + ", " +
                    duckFeeding.FoodQuantity + ", " + duckFeeding.RepetitionDateRangeId + ")";

                command.Connection = connection;
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            catch (Exception exc)
            {
            }

            return response;
        }
    }
}