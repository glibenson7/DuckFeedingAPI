﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

using API.Models;
using API.DataManagers; 

namespace API.DataManagers
{
    public class User_DataManager
    {
        private string connectionString =
            @"Server=localhost\SQLEXPRESS;Database=DuckFeedingDb;persist security info=True;Integrated Security=SSPI;";

        string queryString;
        SqlConnection connection;
        SqlCommand command;
        DataTable tbl;
        DataSet dataSet;
        SqlDataReader reader;
        User user;

        public List<User> GetUserList()
        {
            List<User> userList = new List<User>();

            dataSet = new DataSet();
            tbl = new DataTable();

            try
            {
                SqlConnection connection = new SqlConnection(connectionString);

                string queryString = 
                    "SELECT Id, Userid, FirstName, LastName, " +
                    "Email, Password " +
                "FROM Users ";
                // WHERE Userid = 1;

                connection.Open();
                command = new SqlCommand(queryString, connection);

                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    User user = new User();

                    user.Id = reader.GetInt32(0);
                    user.FirstName = reader.GetString(1);
                    user.LastName = reader.GetString(2);
                    user.Email = reader.GetString(3);

                    userList.Add(user);
                }
            }
            catch (Exception exc)
            {
            }

            return userList;
        }

        public User GetUser()
        {
            user = new User();

            dataSet = new DataSet();
            tbl = new DataTable();

            try
            {
                connection = new SqlConnection(connectionString);

                queryString =
                    "SELECT Id, Userid, FirstName, LastName, " +
                    "Email, Password " +
                "FROM Users ";
                // WHERE Userid = 1;

                connection.Open();
                command = new SqlCommand(queryString, connection);

                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    User user = new User();

                    user.Id = reader.GetInt32(0);
                    user.FirstName = reader.GetString(1);
                    user.LastName = reader.GetString(2);
                    user.Email = reader.GetString(3);
                }
            }
            catch (Exception exc)
            {
            }

            return user;
        }

        public int AddUser(User user)
        {
            int response = 0;
            
            try
            {
                SqlConnection connection = new SqlConnection(connectionString);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = 
                    "INSERT INTO Users (Id, Userid, FirstName, LastName, Email, Password) " +
                    "VALUES (" + user.Id + ", '" + user.Userid + "', '" + user.FirstName + "', '" +
                                 user.LastName + "', '" + user.Email + "', '" + user.Password + "')";

                cmd.Connection = connection;
                connection.Open();
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            catch (Exception exc)
            {
            }

            return response;
        }
    }
}