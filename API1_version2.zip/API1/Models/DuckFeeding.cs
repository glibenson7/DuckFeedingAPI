﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models
{
    public class DuckFeeding
    {
        public int DuckFeedingId { get; set; }
        public string Userid { get; set; }
        public string DateAndTime { get; set; }
        public int FoodDescId { get; set; }
        public int LocationId { get; set; }
        public int DuckCount { get; set; }
        public int FoodKindId { get; set; }
        public float FoodQuantity { get; set; }
        public int RepetitionDateRangeId { get; set; }

        //public string FoodDesc { get; set; }
        //public string Location { get; set; }
        // public string FoodKind { get; set; }
        // public string RepetitionDateRange { get; set; }

        public DuckFeeding()
        {
            DuckFeedingId = 0;
            DateAndTime = "";
            FoodDescId = 0;
            LocationId = 0;
            DuckCount = 0;
            FoodKindId = 0;
            FoodQuantity = 0;
            RepetitionDateRangeId = 0;
        }

        public DuckFeeding(int id, string dateAndTime, int foodDescId, 
                           int locationId, int duckCount, int foodKindId, 
                           int foodQuantity, int repetitionDateRangeId)
        {
            DuckFeedingId = id;
            DateAndTime = dateAndTime;
            FoodDescId = foodDescId;
            LocationId = LocationId;
            DuckCount = duckCount;
            FoodKindId = foodKindId;
            FoodQuantity = foodQuantity;
            RepetitionDateRangeId = repetitionDateRangeId;
        }
    }
}