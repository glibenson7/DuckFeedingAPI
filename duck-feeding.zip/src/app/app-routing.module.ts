import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SigninComponent } from './components/signin/signin.component';
import { ShowDuckFeedingsComponent } from './components/show-duck-feedings/show-duck-feedings.component';
import { AddDuckFeedingComponent }   from './components/add-duck-feeding/add-duck-feeding.component';

// import { LoginComponent } from './components/login/login.component';
// import { EditDuckFeedingComponent }  from './components/edit-duck-feeding/edit-duck-feeding.component';

const routes: Routes = [
  {path:'signin', component:SigninComponent},
  {path:'show-duck-feedings', component:ShowDuckFeedingsComponent},
  {path:'add-duck-feeding',   component:AddDuckFeedingComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }

