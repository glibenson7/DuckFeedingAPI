import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedService } from './shared.service';
import { LoginComponent } from './components/login/login.component';
import { SigninComponent } from './components/signin/signin.component';
import { ShowDuckFeedingsComponent } from './components/show-duck-feedings/show-duck-feedings.component';
import { AddDuckFeedingComponent } from './components/add-duck-feeding/add-duck-feeding.component';
import { EditDuckFeedingComponent } from './components/edit-duck-feeding/edit-duck-feeding.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SigninComponent,
    ShowDuckFeedingsComponent,
    AddDuckFeedingComponent,
    EditDuckFeedingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
