import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDuckFeedingComponent } from './add-duck-feeding.component';

describe('AddDuckFeedingComponent', () => {
  let component: AddDuckFeedingComponent;
  let fixture: ComponentFixture<AddDuckFeedingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddDuckFeedingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDuckFeedingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
