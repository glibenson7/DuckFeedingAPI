import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDuckFeedingComponent } from './edit-duck-feeding.component';

describe('EditDuckFeedingComponent', () => {
  let component: EditDuckFeedingComponent;
  let fixture: ComponentFixture<EditDuckFeedingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditDuckFeedingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDuckFeedingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
