import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'edit-duck-feeding',
  templateUrl: './edit-duck-feeding.component.html',
  styleUrls: ['./edit-duck-feeding.component.css']
})
export class EditDuckFeedingComponent implements OnInit {

  addSts: string = 'to-be-added';

  constructor() { }

  ngOnInit(): void {
  }

  saveDuckFeeding(): void {
    alert("in saveDuckFeeding");
    this.addSts = 'added';
  }
}
