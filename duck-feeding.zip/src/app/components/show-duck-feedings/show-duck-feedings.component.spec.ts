import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowDuckFeedinsComponent } from './show-duck-feedings.component';

describe('ShowDuckFeedinsComponent', () => {
  let component: ShowDuckFeedinsComponent;
  let fixture: ComponentFixture<ShowDuckFeedinsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowDuckFeedinsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowDuckFeedinsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
