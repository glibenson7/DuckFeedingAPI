import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';
import { trigger, state, style, transition, animate } from '@angular/animations';

export class DuckFeeding {
  public Id: number = 0;
  public DateTime: string = "";
  public FoodDesc: string = "";
  public Location: string = "";
  public DuckCount: number = 0;
  public FoodKind: string = "";
  public FoodQuantity: number = 0;

  constructor() {
  }
}

@Component({
  selector: 'show-duck-feedings',
  templateUrl: './show-duck-feedings.component.html',
  styleUrls: ['./show-duck-feedings.component.css']
})
export class ShowDuckFeedingsComponent implements OnInit {

  duckFeedings:any= [];
  duckFeeding:any;

  constructor(private service:SharedService) {

      this.duckFeedings = [
        {
          Id: 1,
          DateTime: "2021.09.01 09:30 am",
          Food: "Farm Boy whole wheat toasts",
          Location: "Ottawa Andrew Hayden Park",
          DuckCount: 5,
          FoodKind: "Toast Set",
          FoodQuantity: 3
        }
      ];
  }

  ngOnInit(): void {
    this.service.getDuckFeedings().subscribe(data=>{
      this.duckFeedings = data;
    });
  }
}
