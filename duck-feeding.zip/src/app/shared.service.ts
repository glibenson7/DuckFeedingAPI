import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class SharedService {
  readonly APIUrl="https://localhost:44354/api";

  constructor(private http:HttpClient) { }

  getDuckFeedings():Observable<any[]> {
    console.log("shared.service getDuckFeedings");
    return this.http.get<any>(this.APIUrl+'/duckFeedings');
  }

  getDuckFeeding():Observable<any[]> {
    console.log("shared.service getDuckFeeding_");
    return this.http.get<any>(this.APIUrl+'/duckFeeding/1');
  }

  addDuckFeeding(){
    console.log("shared.service addDuckFeeding");

    return this.http.post(this.APIUrl+'/duckFeeding/add', "added successfully")
  }

  updateDuckFeeding(val:any){
    console.log("shared.service updateDuckFeeding");
    return this.http.put(this.APIUrl+'/duckFeeding/update', val)
  }

  deleteDuckFeeding(val:any){
    console.log("shared.service deleteDuckFeeding");
    return this.http.delete(this.APIUrl+'/duckFeeding/delete', val)
  }

  addUser(){
    console.log("shared.service addUser");
    return this.http.post(this.APIUrl+'/user/add', "User added")
  }

}
