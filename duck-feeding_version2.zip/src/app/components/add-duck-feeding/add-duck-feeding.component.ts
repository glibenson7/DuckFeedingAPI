import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'add-duck-feeding',
  templateUrl: './add-duck-feeding.component.html',
  styleUrls: ['./add-duck-feeding.component.css']
})
export class AddDuckFeedingComponent implements OnInit {

  apiResponse:any;

  constructor(private service:SharedService) {
  }

  ngOnInit(): void {
  }

  addDuckFeeding(val:any): void {
    alert("in addDuckFeeding");

    this.service.addDuckFeeding(val).subscribe(data=>{
      this.apiResponse = data;
    });
  }
}
