import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class SharedService {
  readonly APIUrl="https://localhost:44354/api";

  constructor(private http:HttpClient) { }

  getDuckFeedingList():Observable<any[]> {
    console.log("shared.service getDuckFeedingList");
    return this.http.get<any>(this.APIUrl + '/duckFeedingList');
  }

  getDuckFeeding(val:any):Observable<any[]> {
    console.log("shared.service getDuckFeeding");
    return this.http.get<any>(this.APIUrl + '/duckFeeding/' + val);
  }

  addDuckFeeding(val:any) {
    console.log("shared.service addDuckFeeding");

    return this.http.post(this.APIUrl + '/duckFeeding/add', val);
  }

/*
  updateDuckFeeding(val:any){
    console.log("shared.service updateDuckFeeding");
    return this.http.put(this.APIUrl + '/duckFeeding/update', val)
  }

  deleteDuckFeeding(val:any){
    console.log("shared.service deleteDuckFeeding");
    return this.http.delete(this.APIUrl + '/duckFeeding/delete', val)
  }
*/

  addUser(val:any) {
    console.log("shared.service addUser");

    return this.http.post(this.APIUrl + '/user/add', "User added")
  }

}
